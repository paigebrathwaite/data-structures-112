package spiderman;

import java.util.*;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * DimensionInputFile name is passed through the command line as args[0]
 * Read from the DimensionsInputFile with the format:
 * 1. The first line with three numbers:
 * i. a (int): number of dimensions in the graph
 * ii. b (int): the initial size of the cluster table prior to rehashing
 * iii. c (double): the capacity(threshold) used to rehash the cluster table
 * 2. a lines, each with:
 * i. The dimension number (int)
 * ii. The number of canon events for the dimension (int)
 * iii. The dimension weight (int)
 * 
 * Step 2:
 * SpiderverseInputFile name is passed through the command line as args[1]
 * Read from the SpiderverseInputFile with the format:
 * 1. d (int): number of people in the file
 * 2. d lines, each with:
 * i. The dimension they are currently at (int)
 * ii. The name of the person (String)
 * iii. The dimensional signature of the person (int)
 * 
 * Step 3:
 * HubInputFile name is passed through the command line as args[2]
 * Read from the HubInputFile with the format:
 * One integer
 * i. The dimensional number of the starting hub (int)
 * 
 * Step 4:
 * CollectedOutputFile name is passed in through the command line as args[3]
 * Output to CollectedOutputFile with the format:
 * 1. e Lines, listing the Name of the anomaly collected with the Spider who
 * is at the same Dimension (if one exists, space separated) followed by
 * the Dimension number for each Dimension in the route (space separated)
 * 
 * @author Seth Kelley
 */

public class CollectAnomalies {

    ArrayList<PersonData> forAnomalyList; 
    ArrayList<AnomalyData> forAnomalies; 
    int forHub;

    public static void main(String[] args) {

        if ( args.length < 4 ) {
        StdOut.println("Execute: java -cp bin spiderman.CollectAnomalies <dimension INput file> <spiderverse INput file> <hub INput file> <collected OUTput file>");
        return;
        }

        //WRITE YOUR CODE HERE

        CollectAnomalies anomalyObj = new CollectAnomalies();
        StdOut.setFile(args[3]);
        anomalyObj.collectAnomalies(args[0], args[1], args[2]);
        anomalyObj.print();

    }

    public ArrayList<PersonData> collectAnomalies(String inputFile, String inputFile2, String inputFile3) {

        Collider colliderObj = new Collider(); // returns adj list
        HashNode[] adjArray = colliderObj.colliderCode(inputFile, inputFile2);

        int graphSize = -1;
        for (int i = 0; i < adjArray.length; i++) {
            HashNode pointer = adjArray[i];

            while (pointer != null) {

                if (pointer.getData().getDimensionCount() > graphSize) {
                    graphSize = pointer.getData().getDimensionCount();
                }

                pointer = pointer.getNextHashNode();
            }

        }

        // create and populate the graph
        Graph graph = new Graph(graphSize + 1);

        for (int i = 0; i < adjArray.length; i++) {
            HashNode pointer = adjArray[i].getNextHashNode();
            int v = adjArray[i].getData().getDimensionCount();

            while (pointer != null) {

                int w = pointer.getData().getDimensionCount();

                graph.addEdge(v, w);
                // graph.addEdge(w, v);
                pointer = pointer.getNextHashNode();

            }

        }

        // StdIn.setFile(inputFile3);

        // read in spider info and store into parallel arrays
        StdIn.setFile(inputFile2);
        int numOfSpiders = StdIn.readInt();
        StdIn.readLine(); // skip to next line

        String[] spiderNames = new String[numOfSpiders];
        PersonData[] dimensionInfo = new PersonData[numOfSpiders];
        ArrayList<PersonData> anomalyList = new ArrayList<PersonData>();
        ArrayList<PersonData> regSpiders = new ArrayList<PersonData>();
        ArrayList<PersonData> forGoHomeMachine = new ArrayList<PersonData>();


        for (int i = 0; i < numOfSpiders; i++) {

            int currentDimension = StdIn.readInt();
            String name = StdIn.readString();
            int signatureDimension = StdIn.readInt();

            PersonData data = new PersonData(currentDimension, signatureDimension);
            PersonData anomalyData = new PersonData(currentDimension, name, signatureDimension);

            anomalyList.add(anomalyData);
            regSpiders.add(anomalyData);
            forGoHomeMachine.add(anomalyData);
            spiderNames[i] = name;
            dimensionInfo[i] = data;

        }
        


        //this is the list for the reg spiders who are in the dimensions they belong to
        //ArrayList<PersonData> regSpiders = anomalyList;

        Iterator<PersonData> regSpiderIterator = regSpiders.iterator();
        while (regSpiderIterator.hasNext()){
            PersonData move = regSpiderIterator.next();
 
            if (move.getCurrDimension() != move.getSignDimension()){
                regSpiderIterator.remove();
 
            }
        }

        regSpiderIterator = null;

        
        StdIn.setFile(inputFile3); // read in hub file
        int hub = StdIn.readInt();


        // remove anyone who is at the hub from the list
        Iterator<PersonData> iterator = anomalyList.iterator();
        while (iterator.hasNext()) {
            PersonData move = iterator.next();

            if (move.getCurrDimension() == hub) {
                iterator.remove();
            }
        }

        iterator = null;


        //removes anyone else who is where they should be (sign dim = curr dim)
        Iterator<PersonData> iterator2 = anomalyList.iterator();
        while (iterator2.hasNext()) {
            PersonData move = iterator2.next();

            if (move.getCurrDimension() == move.getSignDimension()) {
                iterator2.remove();
            }
        }

        iterator2 = null;




        //create a new list JUST FOR anomaly's current dimensions, you need this is to run shortestPath 
        ArrayList<Integer> anomalyCurrDim = new ArrayList<Integer>();
        for (int i = 0; i < anomalyList.size(); i++) {
            anomalyCurrDim.add(anomalyList.get(i).getCurrDimension());

        }

        //for anomaly path/anomaly data
        ArrayList<AnomalyData> anomalies = new ArrayList<AnomalyData>();
        for (int i = 0; i < anomalyList.size(); i++){

            List<Integer> path = graph.shortestPath(hub, anomalyCurrDim.get(i));
            AnomalyData data = new AnomalyData(anomalyList.get(i).getSpiderName(), null, path);

            anomalies.add(data);

        }

        //this is the list for the regular spiders, the while loop takes out anyone who is an anomaly, spiders included 


        //maintence to add spiders to anomalies for anomalydata 
        for (int i = 0; i < anomalyList.size(); i++){
            for (int j = 0; j < regSpiders.size(); j++){
                if (anomalyList.get(i).getCurrDimension() == regSpiders.get(j).getCurrDimension()){
                    anomalies.get(i).setSpider(regSpiders.get(j).getSpiderName());
                }
            }
        }


        //update all of the anomalies' current locations w/ the hub instead of the dimensions they were in
        //you need to know which anomalies are at the hub 
        for (int i = 0; i < forGoHomeMachine.size(); i++){
            for (int j = 0; j < anomalyList.size();j++){
                if (forGoHomeMachine.get(i).getSpiderName().equals(anomalyList.get(j).getSpiderName())){
                    forGoHomeMachine.get(i).setCurrDimension(hub);

                }
            }
        }

        forAnomalyList = anomalyList;
        forAnomalies = anomalies;
        forHub = hub;
        

        return forGoHomeMachine;

    }

    public void print(){

        for (int i = 0; i < forAnomalyList.size(); i++){
            StdOut.print(forAnomalies.get(i).getAnomaly() + " "); //System.out.print(anomalyList.get(i).getSpiderName() + " ");
            

            if (forAnomalies.get(i).getSpider() == null){

            
            for (int j = 0; j < forAnomalies.get(i).getDimensionPath().size(); j++){
                StdOut.print(forAnomalies.get(i).getDimensionPath().get(j) + " ");

            }


            for (int j = forAnomalies.get(i).getDimensionPath().size()-1; j > 0; j--){
               if (j != forHub){

                StdOut.print(forAnomalies.get(i).getDimensionPath().get(j-1) + " ");

               }

            }

            } else {
                StdOut.print(forAnomalies.get(i).getSpider() + " ");
                for (int j = forAnomalies.get(i).getDimensionPath().size()-1; j >= 0; j--){
                    if (j != forHub){
     
                        StdOut.print(forAnomalies.get(i).getDimensionPath().get(j) + " ");
     
                    }
     
                }

            }

            StdOut.println();
        }


    }
}
