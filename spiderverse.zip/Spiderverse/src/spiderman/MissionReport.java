package spiderman;

import java.util.*;

public class MissionReport {

    String name;
    boolean missionStatus;
    int canonEvents;
    List<Integer> pathHome;

    public MissionReport() {
        name = "null";
        missionStatus = false;
        canonEvents = -1;
        pathHome = null;

    }

    public MissionReport(int canonEvents, String name, boolean missionStatus, List<Integer> pathHome) {
        this.name = name;
        this.missionStatus = missionStatus;
        this.canonEvents = canonEvents;
        this.pathHome = pathHome;

    }

    public String getName() {
        return name;

    }

    public void setName(String name) {
        this.name = name;

    }

    public boolean getMissionStatus() {
        return missionStatus;

    }

    public void setMissionStatus(boolean mission) {
        missionStatus = mission;

    }

    public int getCanonEvents() {
        return canonEvents;
    }

    public void setCanonEvents(int event) {
        canonEvents = event;

    }

    public List<Integer> getPath() {
        return pathHome;

    }

    public void setPath(List<Integer> wayHome) {
        pathHome = wayHome;
    }

}
