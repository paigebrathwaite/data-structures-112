package spiderman;

import java.util.ArrayList;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * DimensionInputFile name is passed through the command line as args[0]
 * Read from the DimensionsInputFile with the format:
 * 1. The first line with three numbers:
 * i. a (int): number of dimensions in the graph
 * ii. b (int): the initial size of the cluster table prior to rehashing
 * iii. c (double): the capacity(threshold) used to rehash the cluster table
 * 2. a lines, each with:
 * i. The dimension number (int)
 * ii. The number of canon events for the dimension (int)
 * iii. The dimension weight (int)
 * 
 * Step 2:
 * SpiderverseInputFile name is passed through the command line as args[1]
 * Read from the SpiderverseInputFile with the format:
 * 1. d (int): number of people in the file
 * 2. d lines, each with:
 * i. The dimension they are currently at (int)
 * ii. The name of the person (String)
 * iii. The dimensional signature of the person (int)
 * 
 * Step 3:
 * ColliderOutputFile name is passed in through the command line as args[2]
 * Output to ColliderOutputFile with the format:
 * 1. e lines, each with a different dimension number, then listing
 * all of the dimension numbers connected to that dimension (space separated)
 * 
 * @author Seth Kelley
 */

public class Collider {

    HashNode[] clusters;
    HashNode [] forPrint;

    public static void main(String[] args) {

        if (args.length < 3) {
            StdOut.println("Execute: java -cp bin spiderman.Collider <dimension INput file> <spiderverse INput file> <collider OUTput file>");
        
            return;
        }

        Collider tester = new Collider();

        StdOut.setFile(args[2]);
        tester.colliderCode(args[0], args[1]);
        tester.printAdjList();
       

    }

    public HashNode[] colliderCode(String inputFile, String inputFile2) {

        Clusters cluster = new Clusters();
        clusters = cluster.clustersCode(inputFile);

        StdIn.setFile(inputFile2);
        int numOfSpiders = StdIn.readInt();
        StdIn.readLine(); // skip to next line

        String[] spiderNames = new String[numOfSpiders];
        PersonData[] dimensionInfo = new PersonData[numOfSpiders];

        // use twin arrays to put in all spider names and their dimensions
        for (int i = 0; i < numOfSpiders; i++) {

            int currentDimension = StdIn.readInt();
            String name = StdIn.readString();
            int signatureDimension = StdIn.readInt();

            PersonData data = new PersonData(currentDimension, signatureDimension);

            spiderNames[i] = name;
            dimensionInfo[i] = data;

        }

        // for (int i = 0; i < spiderNames.length; i++){
        // System.out.println(spiderNames[i]);

        // }

        ArrayList<HashNode> adjList = new ArrayList<HashNode>();
        ArrayList<Integer> holder = new ArrayList<Integer>();

        //add every dimension into an arraylist
        for (int i = 0; i < clusters.length; i++) {
            HashNode pointer = clusters[i];

            while (pointer != null) {

                if (!holder.contains(pointer.getData().getDimensionCount())) {
                    HashNode temp = new HashNode(pointer.getData(), null);
                    holder.add(pointer.getData().getDimensionCount());
                    adjList.add(temp);


                }

                pointer = pointer.getNextHashNode();

            }

        }

        //add every dimension into array of linked lists
        HashNode[] adjArray = new HashNode[adjList.size()];

        //create adj array
        for (int i = 0; i < adjArray.length; i++){
            adjArray[i] = adjList.get(i); 

        }

        for (int i = 0; i < clusters.length; i++){

            HashNode pointer = clusters[i].getNextHashNode();
            int index = findIndex(adjArray, clusters[i].getData().getDimensionCount());

            while (pointer != null){
                HashNode adjPointer = adjArray[index];
                int index2 = findIndex(adjArray, pointer.getData().getDimensionCount());
                HashNode childPointer = adjArray[index2] ;

                while (adjPointer != null){

                    if (adjPointer.getNextHashNode() == null){
                        HashNode temp = findNode(adjList, pointer.getData().getDimensionCount());
                        HashNode insert = new HashNode(temp.getData(), null);

                        adjPointer.setNextHashNode(insert);
                        break;

                    }

                    adjPointer = adjPointer.getNextHashNode();

                }

                while (childPointer != null){

                    if(childPointer.getNextHashNode() == null){ 

                        HashNode temp = findNode(adjList, clusters[i].getData().getDimensionCount());
                        HashNode insert = new HashNode(temp.getData(), null);

                        childPointer.setNextHashNode(insert);
                        break;


                    }

                    childPointer = childPointer.getNextHashNode();
                }

                pointer = pointer.getNextHashNode();
            }

            
        }

        forPrint = adjArray;
        return adjArray;

    }

    public void printAdjList(){

        //print adj list 
        for (int i = 0; i < forPrint.length; i++) {
            HashNode pointer = forPrint[i];

            while (pointer != null){
                StdOut.print(pointer.getData().getDimensionCount() + " ");

                pointer = pointer.getNextHashNode();

            }

            StdOut.println();

        }
    }

    public int findIndex(HashNode[] array, int lookingFor) {

        for (int i = 0; i < array.length; i++) {
            if (array[i].getData().getDimensionCount() == lookingFor) {
                return i;

            }
        }

        return -1;

    }

    public HashNode findNode(ArrayList<HashNode> list, int lookingFor) {

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getData().getDimensionCount() == lookingFor) {
                return list.get(i);

            }
        }

        return null;

    }
}