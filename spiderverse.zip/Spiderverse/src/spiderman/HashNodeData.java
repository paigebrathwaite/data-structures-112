package spiderman;

import java.util.*;

public class HashNodeData {

    private int dimensionCount;
    private int canonEventCount;
    private int dimensionWeight;

    //default constructor
    public HashNodeData() {

        dimensionCount = 0;
        canonEventCount = 0;
        dimensionWeight = 0;

    }

    //constructor
    public HashNodeData(int dimensionCount, int canonEventCount, int dimensionWeight) {

        this.dimensionCount = dimensionCount;
        this.canonEventCount = canonEventCount;
        this.dimensionWeight = dimensionWeight;
        // dimensionCount = this.dimensionCount;
        // canonEventCount = this.canonEventCount;
        // dimensionWeight = this.dimensionWeight;

    }

    public int getDimensionCount() {
        return dimensionCount;

    }

    public void setDimensionCount(int dimensionCount){
        this.dimensionCount = dimensionCount;

        
    }

    public int getCanonEventCount(){
        return canonEventCount;

    }

    public void setCanonEventCount(int canonEventCount){
        this.canonEventCount = canonEventCount;

    }

    public int getDimensionWeight(){
        return dimensionWeight;

    }

    public void setDimensionWeight(int dimensionWeight){
        this.dimensionWeight = dimensionWeight;
    }

}
