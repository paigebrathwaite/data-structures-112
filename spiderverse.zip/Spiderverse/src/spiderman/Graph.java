package spiderman;
import java.util.*;

public class Graph {

    private int V;
    private LinkedList<Integer>[] adj;
    private boolean check;

    // constructor
    public Graph(int v) {
        V = v;
        adj = new LinkedList[v];

        for (int i = 0; i < v; i++) {
            adj[i] = new LinkedList();

        }

        check = false;

    }

    public List<Integer> shortestPath(int start, int target) {
        boolean[] visited = new boolean[V];
        int[] parent = new int[V]; // store parent of each vertex

        Queue<Integer> queue = new LinkedList<>();
        queue.add(start);
        visited[start] = true;
        parent[start] = -1; // no parent for the starting vertex

        while (!queue.isEmpty()) {
            int current = queue.poll();

            if (current == target) {
                // Reconstruct the path from start to target
                List<Integer> path = new ArrayList<>();
                int node = target;
                while (node != -1) {
                    path.add(node);
                    node = parent[node];
                }
                Collections.reverse(path);
                return path;
            }

            // search children of the current vertex
            for (int kids : adj[current]) {
                if (!visited[kids]) {
                    visited[kids] = true;
                    parent[kids] = current;
                    queue.add(kids);
                }
            }
        }

        // If target vertex is not reachable from start vertex
        return Collections.emptyList();
    }


    public void addEdge(int v, int w) {
        // add w to v
        adj[v].add(w);

    }

    public void DFSHelper(int v, int test, boolean visited[]) {
        // mark visited node

            visited[v] = true;

            if (check == false) {
                if (v == test) {
                    check = true;
                } 

                StdOut.print(v + " ");
            }
            

            // add all of vertex's children
            Iterator<Integer> kids = adj[v].listIterator();

            while (kids.hasNext()) {
                int next = kids.next();

                if (!visited[next]) {
                    DFSHelper(next, test, visited);
                }

            }
        }
    

    public void DFS(int v, int test) {

        boolean visited[] = new boolean[V];
        DFSHelper(v, test, visited);

    }

}
