package spiderman;

public class PersonNode {

    PersonData data;
    PersonNode next;


    public PersonNode(){
        data = null;
        next = null;

    }

    public PersonNode(PersonData data, PersonNode next){
        this.data = data;
        this.next = next; 

    }

    public PersonData getPersonData(){
        return data;

    }

    public void setPersonData(PersonData dataInput){

        data = dataInput;

    }

    public PersonNode getNextPersonNode(){
        return next;

    }

    public void setNextPersonNode(PersonNode nextNode){
        next = nextNode;

    }
    
}
