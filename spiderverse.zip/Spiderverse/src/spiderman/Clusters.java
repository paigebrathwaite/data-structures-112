package spiderman;

import java.util.*;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * DimensionInputFile name is passed through the command line as args[0]
 * Read from the DimensionsInputFile with the format:
 * 1. The first line with three numbers:
 * i. a (int): number of dimensions in the graph
 * ii. b (int): the initial size of the cluster table prior to rehashing
 * iii. c (double): the capacity(threshold) used to rehash the cluster table
 * 
 * Step 2:
 * ClusterOutputFile name is passed in through the command line as args[1]
 * Output to ClusterOutputFile with the format:
 * 1. n lines, listing all of the dimension numbers connected to
 * that dimension in order (space separated)
 * n is the size of the cluster table.
 * 
 * @author Seth Kelley
 */

public class Clusters {

    private HashNode[] clusters;

    public HashNode[] getClusters() {
        return clusters;

    }

    public static void main(String[] args) {

        if (args.length < 2) {
            StdOut.println(
                    "Execute: java -cp bin spiderman.Clusters <dimension INput file> <collider OUTput file>");
            return;
        }

        Clusters tester = new Clusters();
        tester.clustersCode(args[0]);

        StdOut.setFile(args[1]);
        tester.printTable();


    }

    public HashNode[] clustersCode(String inputFile) {

        StdIn.setFile(inputFile);

        int numOfDimen = StdIn.readInt();
        int initialHashSize = StdIn.readInt();
        Double hashThreshold = StdIn.readDouble();
        StdIn.readLine();
        int currentDimensionCount = 0;

        HashNode[] holder = new HashNode[initialHashSize];
        clusters = holder;

        for (int i = 0; i < numOfDimen; i++) {

            int dimensionNumber = StdIn.readInt();
            int numOfCanonEvents = StdIn.readInt();
            int dimensionWeight = StdIn.readInt();
            StdIn.readLine();

            HashNodeData data = new HashNodeData(dimensionNumber, numOfCanonEvents, dimensionWeight);
            HashNode node = new HashNode(data, null);

            int index = dimensionNumber % clusters.length;
            

            // if index at that table is empty, enter in the dimension node
            if (clusters[index] == null) {
                clusters[index] = node;
                currentDimensionCount++;

            } else {

                // if it isn't empty, replace the new node at the beginning of the list
                node.setNextHashNode(clusters[index]);
                clusters[index] = node;
                currentDimensionCount++;

            }

            if (currentDimensionCount / clusters.length >= hashThreshold) {

                // need to rehash
                HashNode[] rehash = new HashNode[clusters.length * 2];

                for (int j = 0; j < clusters.length; j++) {
                    HashNode pointer = clusters[j];
                    HashNode pointer2 = clusters[j];

                    while (pointer2 != null) {
                        int newIndex = pointer.getData().getDimensionCount() % rehash.length;

                        if (rehash[newIndex] == null) {

                            HashNode newNode = new HashNode(pointer.getData(), null);
                            rehash[newIndex] = newNode;

                        } else {

                            HashNode newNode = new HashNode(pointer.getData(), null);

                            newNode.setNextHashNode(rehash[newIndex]);
                            rehash[newIndex] = newNode;
                            // System.out.println("The dimension of pointer is " +
                            // pointer.getData().getDimensionCount());

                        }

                        pointer2 = pointer2.getNextHashNode();
                        pointer = pointer2;

                    }

                }

                clusters = rehash;

            }


        }


        for (int i = 0; i < clusters.length; i++){
            HashNode pointer = clusters[i];

            if (pointer == clusters[0]){

                while (pointer != null){

                    if (pointer.getNextHashNode() == null){

                        HashNode dimensionTwo = new HashNode(clusters[clusters.length-2].getData(), null);
                        HashNode dimensionOne = new HashNode(clusters[clusters.length-1].getData(), dimensionTwo);

                        pointer.setNextHashNode(dimensionOne);
                        break;

                    }

                    pointer = pointer.getNextHashNode();

                }

            } else if(pointer == clusters[1]){

                while (pointer != null){

                    if (pointer.getNextHashNode() == null){

                        HashNode dimensionTwo = new HashNode(clusters[clusters.length-1].getData(), null);
                        HashNode dimensionOne = new HashNode(clusters[0].getData(), dimensionTwo);

                        pointer.setNextHashNode(dimensionOne);
                        break;

                    }

                    pointer = pointer.getNextHashNode();

                }

            } else {

                while (pointer != null){

                    if (pointer.getNextHashNode() == null){

                        HashNode dimensionTwo = new HashNode(clusters[i-2].getData(), null);
                        HashNode dimensionOne = new HashNode(clusters[i-1].getData(), dimensionTwo);

                        pointer.setNextHashNode(dimensionOne);
                        break;
                        //System.out.println("hi");

                    }

                    pointer = pointer.getNextHashNode();
                }

            }
        }


        return clusters;

    }

    public void printTable() {

        for (int a = 0; a < clusters.length; a++) {
            HashNode pointer = clusters[a];

            while (pointer != null) {
                StdOut.print(" " + pointer.getData().getDimensionCount());

                pointer = pointer.getNextHashNode();
            }

            StdOut.println();

        }

    }

}
