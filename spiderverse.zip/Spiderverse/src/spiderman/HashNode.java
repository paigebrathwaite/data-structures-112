package spiderman;

import java.util.*;

public class HashNode {

    private HashNodeData data;
    private int dimension;
    private HashNode next; 


    // you need to have a key (the index the info is at) and then the value should
    // be a data object holding canon events,
    // dimension weight, etc.


    public HashNode(){

        dimension = 0;
        data = null; 
        next = null;
    }

        // Constructor

        public HashNode(HashNodeData data, HashNode next) {

            this.data = data;
            this.next = next;

        }

        public HashNode(int dimension, HashNode next) {

            this.dimension = dimension;
            this.next = next;

        }

        // public int getHashLength() {
        //     return hashTable.size();
        // }

        public int getDimension() {
            return dimension;

        }

        public void setDimension(int num) {
            dimension = num;

        }




        public HashNodeData getData() {
            return data;

        }

        public void setData(HashNodeData dataInput) {
            data = dataInput;

        }

        public HashNode getNextHashNode() {
            return next;
        }

        public void setNextHashNode(HashNode nextNode) {
            next = nextNode;

        }



    }


