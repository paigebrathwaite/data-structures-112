package spiderman;

import java.util.*;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * DimensionInputFile name is passed through the command line as args[0]
 * Read from the DimensionsInputFile with the format:
 * 1. The first line with three numbers:
 * i. a (int): number of dimensions in the graph
 * ii. b (int): the initial size of the cluster table prior to rehashing
 * iii. c (double): the capacity(threshold) used to rehash the cluster table
 * 2. a lines, each with:
 * i. The dimension number (int)
 * ii. The number of canon events for the dimension (int)
 * iii. The dimension weight (int)
 * 
 * Step 2:
 * SpiderverseInputFile name is passed through the command line as args[1]
 * Read from the SpiderverseInputFile with the format:
 * 1. d (int): number of people in the file
 * 2. d lines, each with:
 * i. The dimension they are currently at (int)
 * ii. The name of the person (String)
 * iii. The dimensional signature of the person (int)
 * 
 * Step 3:
 * HubInputFile name is passed through the command line as args[2]
 * Read from the SpotInputFile with the format:
 * One integer
 * i. The dimensional number of the starting hub (int)
 * 
 * Step 4:
 * AnomaliesInputFile name is passed through the command line as args[3]
 * Read from the AnomaliesInputFile with the format:
 * 1. e (int): number of anomalies in the file
 * 2. e lines, each with:
 * i. The Name of the anomaly which will go from the hub dimension to their home
 * dimension (String)
 * ii. The time allotted to return the anomaly home before a canon event is
 * missed (int)
 * 
 * Step 5:
 * ReportOutputFile name is passed in through the command line as args[4]
 * Output to ReportOutputFile with the format:
 * 1. e Lines (one for each anomaly), listing on the same line:
 * i. The number of canon events at that anomalies home dimensionafter being
 * returned
 * ii. Name of the anomaly being sent home
 * iii. SUCCESS or FAILED in relation to whether that anomaly made it back in
 * time
 * iv. The route the anomaly took to get home
 * 
 * @author Seth Kelley
 */

public class GoHomeMachine {

    HashNodeData[] dimensionArray;
    MissionReport[] reportListForPrint;

    public static void main(String[] args) {

        if (args.length < 5) {
            StdOut.println(
                    "Execute: java -cp bin spiderman.GoHomeMachine <dimension INput file> <spiderverse INput file> <hub INput file> <anomalies INput file> <report OUTput file>");
            return;
        }

        GoHomeMachine testGoHomeMachine = new GoHomeMachine();
        testGoHomeMachine.goHomeMachineCode(args[0], args[1], args[2], args[3]);
        StdOut.setFile(args[4]);
        testGoHomeMachine.printReport();

    }

    public void goHomeMachineCode(String inputFile, String inputFile2, String inputFile3, String inputFile4) {

        CollectAnomalies collectAnomalies = new CollectAnomalies();
        Collider collider = new Collider();
        HashNode[] adjArray = collider.colliderCode(inputFile, inputFile2);

        // list of everyone, but importantly has the people at the hub, including
        // anomalies
        ArrayList<PersonData> peopleAtHub = collectAnomalies.collectAnomalies(inputFile, inputFile2, inputFile3);
        ArrayList<HashNodeData> dimensionList = new ArrayList<>();
        ArrayList<AnomalyData> goBackHomePeople = new ArrayList<>();

        StdIn.setFile(inputFile); // open dimension.in

        int numOfDimen = StdIn.readInt();
        HashNodeData[] arrayOfDimensions = new HashNodeData[numOfDimen];
        StdIn.readInt(); // this is the initialHashSize
        StdIn.readDouble(); // this is the hashThreshold
        StdIn.readLine(); // skip to end of line

        // start adding the dimensions into the arraylist, dimensionList
        for (int i = 0; i < numOfDimen; i++) {

            int dimensionNumber = StdIn.readInt();
            int numOfCanonEvents = StdIn.readInt();
            int dimensionWeight = StdIn.readInt();
            StdIn.readLine();

            HashNodeData data = new HashNodeData(dimensionNumber, numOfCanonEvents, dimensionWeight);
            dimensionList.add(data);
            arrayOfDimensions[i] = data;

        }

        dimensionArray = arrayOfDimensions;

        StdIn.setFile(inputFile3); // open hub.in
        int hub = StdIn.readInt();

        StdIn.setFile(inputFile4); // open anomalies.in
        int numOfReturnees = StdIn.readInt();

        for (int i = 0; i < numOfReturnees; i++) {

            String name = StdIn.readString();
            int timeAlloted = StdIn.readInt();
            StdIn.readLine(); // skip to next line

            AnomalyData data = new AnomalyData(name, timeAlloted);
            goBackHomePeople.add(data);

        }

        // remove anyone who is not at the hub or not on the anomaly file list from the
        // list
        Iterator<PersonData> iterator = peopleAtHub.iterator();
        while (iterator.hasNext()) {
            PersonData person = iterator.next();
            boolean check = false;

            for (AnomalyData goBackHomePerson : goBackHomePeople) {
                if (person.getSpiderName().equals(goBackHomePerson.getAnomaly())) {
                    check = true;
                    break;
                }
            }

            if (!check) {
                iterator.remove();
            }

        }

        // find graph size
        int graphSize = -1;
        for (int i = 0; i < adjArray.length; i++) {
            HashNode pointer = adjArray[i];

            while (pointer != null) {

                if (pointer.getData().getDimensionCount() > graphSize) {
                    graphSize = pointer.getData().getDimensionCount();
                }

                pointer = pointer.getNextHashNode();
            }

        }

        // create and populate the graph
        WeightedGraph graph = new WeightedGraph(graphSize + 1);

        for (int i = 0; i < adjArray.length; i++) {
            HashNode pointer = adjArray[i].getNextHashNode();
            int v = adjArray[i].getData().getDimensionCount();

            while (pointer != null) {

                int w = pointer.getData().getDimensionCount();
                int weight = pointer.getData().getDimensionWeight();

                graph.addEdge(v, w, weight);
                // graph.addEdge(w, v);
                pointer = pointer.getNextHashNode();

            }

        }

        // List<Integer> path = graph.dijkstra(928, 65);

        MissionReport[] listOfReports = new MissionReport[peopleAtHub.size()];

        // populates report w/ canon events, name, and path !!!NOT MISSION STATUS
        for (int i = 0; i < peopleAtHub.size(); i++) {
            List<Integer> path = graph.dijkstra(hub, peopleAtHub.get(i).getSignDimension());
            int index = findIndex(arrayOfDimensions, peopleAtHub.get(i).getSignDimension());
            int canonEvents = arrayOfDimensions[index].getCanonEventCount();
            MissionReport report = new MissionReport(canonEvents, peopleAtHub.get(i).getSpiderName(), false, path);
            listOfReports[i] = report;

        }

        // update the canon event count and mission status using the weight of the path
        for (int i = 0; i < listOfReports.length; i++) {
            int totPathWeight = 0;

            for (int j = 1; j < listOfReports[i].getPath().size(); j++) {

                int index = findIndex(arrayOfDimensions, listOfReports[i].getPath().get(j));

                int prevIndex = findIndex(arrayOfDimensions, listOfReports[i].getPath().get(j - 1));
                totPathWeight = totPathWeight + arrayOfDimensions[index].getDimensionWeight()
                        + arrayOfDimensions[prevIndex].getDimensionWeight();

            }

            int anomalyListIndex = findNameIndex(goBackHomePeople, listOfReports[i].getName());
            if (totPathWeight < goBackHomePeople.get(anomalyListIndex).getTime()) {

                listOfReports[i].setMissionStatus(true);

            } else {
                int canonEvents = listOfReports[i].getCanonEvents();
                listOfReports[i].setCanonEvents(canonEvents - 1);

            }

        }

        reportListForPrint = listOfReports;

    }

    public void printReport() {

        for (int i = 0; i < reportListForPrint.length; i++) {

            if (reportListForPrint[i].getMissionStatus() == true) {

                StdOut.print(reportListForPrint[i].getCanonEvents() + " ");
                StdOut.print(reportListForPrint[i].getName() + " ");
                StdOut.print("SUCCESS" + " ");

                for (int j = 0; j < reportListForPrint[i].getPath().size(); j++) {
                    StdOut.print(reportListForPrint[i].getPath().get(j) + " ");

                }

                StdOut.println();

            } else {

                StdOut.print(reportListForPrint[i].getCanonEvents() + " ");
                StdOut.print(reportListForPrint[i].getName() + " ");
                StdOut.print("FAILED" + " ");

                for (int j = 0; j < reportListForPrint[i].getPath().size(); j++) {
                    StdOut.print(reportListForPrint[i].getPath().get(j) + " ");

                }

                StdOut.println();

            }

        }

    }

    public int findIndex(HashNodeData[] array, int lookingFor) {

        for (int i = 0; i < array.length; i++) {
            if (array[i].getDimensionCount() == lookingFor) {
                return i;

            }
        }

        return -1;

    }

    public int findNameIndex(ArrayList<AnomalyData> list, String name) {

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getAnomaly().equalsIgnoreCase(name)) {

                return i;

            }
        }

        return -1;

    }

}
