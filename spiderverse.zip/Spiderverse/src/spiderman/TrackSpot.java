package spiderman;

/**
 * Steps to implement this class main method:
 * 
 * Step 1:
 * DimensionInputFile name is passed through the command line as args[0]
 * Read from the DimensionsInputFile with the format:
 * 1. The first line with three numbers:
 * i. a (int): number of dimensions in the graph
 * ii. b (int): the initial size of the cluster table prior to rehashing
 * iii. c (double): the capacity(threshold) used to rehash the cluster table
 * 2. a lines, each with:
 * i. The dimension number (int)
 * ii. The number of canon events for the dimension (int)
 * iii. The dimension weight (int)
 * 
 * Step 2:
 * SpiderverseInputFile name is passed through the command line as args[1]
 * Read from the SpiderverseInputFile with the format:
 * 1. d (int): number of people in the file
 * 2. d lines, each with:
 * i. The dimension they are currently at (int)
 * ii. The name of the person (String)
 * iii. The dimensional signature of the person (int)
 * 
 * Step 3:
 * SpotInputFile name is passed through the command line as args[2]
 * Read from the SpotInputFile with the format:
 * Two integers (line seperated)
 * i. Line one: The starting dimension of Spot (int)
 * ii. Line two: The dimension Spot wants to go to (int)
 * 
 * Step 4:
 * TrackSpotOutputFile name is passed in through the command line as args[3]
 * Output to TrackSpotOutputFile with the format:
 * 1. One line, listing the dimenstional number of each dimension Spot has
 * visited (space separated)
 * 
 * @author Seth Kelley
 */

public class TrackSpot {

    Graph globalGraph;

    public static void main(String[] args) {

        if (args.length < 4) {
            StdOut.println(
                    "Execute: java -cp bin spiderman.TrackSpot <dimension INput file> <spiderverse INput file> <spot INput file> <trackspot OUTput file>");
            return;
        }

        Clusters cluster = new Clusters();
        Collider collider = new Collider();
        TrackSpot trackSpot = new TrackSpot();

        StdOut.setFile(args[3]);
        trackSpot.trackSpotCode(args[0], args[1], args[2]);

    }

    public Graph trackSpotCode(String inputFile, String inputFile2, String inputFile3) {

        Collider colliderArray = new Collider();
        HashNode[] adjArray = colliderArray.colliderCode(inputFile, inputFile2);

        StdIn.setFile(inputFile3);

        int startDimen = StdIn.readInt();
        StdIn.readLine(); // skip to next line
        int endDimen = StdIn.readInt();

        //find the size of the graph
        int graphSize = -1; 
        for (int i = 0; i < adjArray.length; i++) {
            HashNode pointer = adjArray[i];

            while (pointer != null){
                
                if (pointer.getData().getDimensionCount() > graphSize){
                    graphSize = pointer.getData().getDimensionCount();
                }

                pointer = pointer.getNextHashNode();
            }

        }

        //create and populate the graph
        Graph graph = new Graph(graphSize+1);

        for (int i = 0; i < adjArray.length; i++) {
            HashNode pointer = adjArray[i].getNextHashNode();
            int v = adjArray[i].getData().getDimensionCount();

            while (pointer != null) {

                int w = pointer.getData().getDimensionCount();

                graph.addEdge(v, w);
                //graph.addEdge(w, v);
                pointer = pointer.getNextHashNode();

            }

        }

        globalGraph = graph; 

        //call dfs 
        graph.DFS(startDimen, endDimen);

        return globalGraph; 

    }
}
