package spiderman;

public class PersonData {

    private int currDimension; 
    private String spiderName;
    private int signDimension;


    public PersonData(){

        currDimension = 0;
        spiderName = "Null"; 
        signDimension = 0; 

    }

    //constructor
    public PersonData(int currDimension, String spiderName, int signDimension){

        this.currDimension = currDimension;
        this.spiderName = spiderName;
        this.signDimension = signDimension;

    }

    public PersonData(int currDimension, int signDimension){

        this.currDimension = currDimension;
        this.signDimension = signDimension;

    }

    public int getCurrDimension(){
        return currDimension;

    }

    public void setCurrDimension(int currDimension){
        this.currDimension = currDimension;

    }

    public String getSpiderName(){
        return spiderName;

    }

    public void setSpiderName(String spiderName){
        this.spiderName = spiderName;

    }

    public int getSignDimension(){
        return signDimension;

    }

    public void setSignDimension(int signDimension){
        this.signDimension = signDimension;
    }

    
}
