package spiderman;

import java.util.*;
 
public class WeightedGraph {
    private int V; 
    private List<List<Node>> adj; 

    class Node {

        int dest;
        int weight;

        Node(int destination, int weight){
            this.dest = destination;
            this.weight = weight;
        }
    }

    public WeightedGraph(int vertex){
        this.V = vertex;
        adj = new ArrayList<>(vertex);

        for (int i = 0; i < vertex; i++){
            adj.add(new ArrayList<>());

        }
    }

    public void addEdge(int source, int destination, int weight){

        adj.get(source).add(new Node(destination, weight));
        adj.get(destination).add(new Node(source, weight)); 

    }

    public List<Integer> dijkstra(int start, int dest){

        PriorityQueue<Node> pq = new PriorityQueue<>(V, Comparator.comparingInt(node -> node.weight));  //for vertex distances
        int[] dist = new int[V]; //store shortest distances
        Arrays.fill(dist, Integer.MAX_VALUE);
    
        int[] parent = new int[V]; //store path
        Arrays.fill(parent, -1);
    
        pq.add(new Node(start, 0)); //start vertex first
        dist[start] = 0;
    
        while (!pq.isEmpty()) {
            
            int vertex = pq.poll().dest;
            if (vertex == dest)
                break;
    
            for (Node neighbor : adj.get(vertex)) {
                int v = neighbor.dest;
                int weight = neighbor.weight;
    
                if (dist[vertex] != Integer.MAX_VALUE && dist[vertex] + weight < dist[v]) {
                    dist[v] = dist[vertex] + weight;
                    parent[v] = vertex; 
                    pq.add(new Node(v, dist[v]));
                }
            }
        }
    
        List<Integer> path = new ArrayList<>(); //shortest path from source to destination
        for (int at = dest; at != -1; at = parent[at]) {
            path.add(at);

        }

        Collections.reverse(path);
        return path;

    }
}