package spiderman;

import java.util.*;

public class AnomalyData {

    String anomaly;
    String spider;
    List<Integer> dimensionPath;
    int time; 

    public AnomalyData() {
        anomaly = "null";
        spider = "null";
        dimensionPath = null;
        time = -1; 

    }

    public AnomalyData(String anomaly, String spider, List<Integer> dimensionPath) {

        this.anomaly = anomaly;
        this.spider = spider;
        this.dimensionPath = dimensionPath;

    }

    public AnomalyData(String anomaly, int time) {

        this.anomaly = anomaly;
        this.time = time;

    }

    public String getAnomaly() {
        return anomaly;

    }

    public String getSpider() {
        return spider;

    }

    public List<Integer> getDimensionPath() {
        return dimensionPath;

    }

    public void setSpider(String name) {
        this.spider = name;
    }

    public int getTime(){
        return time;

    }

    public void setTime(int timeLeft){
        this.time = timeLeft;

    }

}
