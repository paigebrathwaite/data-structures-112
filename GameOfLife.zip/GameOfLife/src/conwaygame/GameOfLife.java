package conwaygame;
import java.util.ArrayList;


/**
 * Conway's Game of Life Class holds various methods that will
 * progress the state of the game's board through it's many
 * iterations/generations.
 *
 * Rules
 * Alive cells with 0-1 neighbors die of loneliness.
 * Alive cells with >=4 neighbors die of overpopulation.
 * Alive cells with 2-3 neighbors survive.
 * Dead cells with exactly 3 neighbors become alive by reproduction.
 * 
 * @author Seth Kelley
 * @author Maxwell Goldberg
 */
public class GameOfLife {

    // Instance variables
    private static final boolean ALIVE = true;
    private static final boolean DEAD = false;

    private boolean[][] grid; // The board has the current generation of cells
    private int totalAliveCells; // Total number of alive cells in the grid (board)

    /**
     * Default Constructor which creates a small 5x5 grid with five alive cells.
     * This variation does not exceed bounds and dies off after four iterations.
     */
    public GameOfLife() {
        grid = new boolean[5][5];
        totalAliveCells = 5;
        grid[1][1] = ALIVE;
        grid[1][3] = ALIVE;
        grid[2][2] = ALIVE;
        grid[3][2] = ALIVE;
        grid[3][3] = ALIVE;
    }

    /**
     * Constructor used that will take in values to create a grid with a given
     * number
     * of alive cells
     * 
     * @param file is the input file with the initial game pattern formatted as
     *             follows:
     *             An integer representing the number of grid rows, say r
     *             An integer representing the number of grid columns, say c
     *             Number of r lines, each containing c true or false values (true
     *             denotes an ALIVE cell)
     */
    public GameOfLife(String file) {

        StdIn.setFile(file);
        int rows = StdIn.readInt();
        int col = StdIn.readInt();
        grid = new boolean[rows][col];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < col; j++) {
                grid[i][j] = StdIn.readBoolean();
            }
        }

    }

    /**
     * Returns grid
     * 
     * @return boolean[][] for current grid
     */
    public boolean[][] getGrid() {
        return grid;
    }

    /**
     * Returns totalAliveCells
     * 
     * @return int for total number of alive cells in grid
     */
    public int getTotalAliveCells() {
        return totalAliveCells;
    }

    /**
     * Returns the status of the cell at (row,col): ALIVE or DEAD
     * 
     * @param row row position of the cell
     * @param col column position of the cell
     * @return true or false value "ALIVE" or "DEAD" (state of the cell)
     */
    public boolean getCellState(int row, int col) {

        if (grid[row][col] == true) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns true if there are any alive cells in the grid
     * 
     * @return true if there is at least one cell alive, otherwise returns false
     */
    public boolean isAlive() {

        boolean check = false;

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j] == true) {
                    check = true;
                    break;
                }

            }
        }

        return check;
    }

    /**
     * Determines the number of alive cells around a given cell.
     * Each cell has 8 neighbor cells which are the cells that are
     * horizontally, vertically, or diagonally adjacent.
     * 
     * @param col column position of the cell
     * @param row row position of the cell
     * @return neighboringCells, the number of alive cells (at most 8).
     */

    public int numOfAliveNeighbors(int row, int col) {

        int aliveCells = 0;

        int[][] edgeCases = { { -1, -1 }, { -1, 0 }, { -1, 1 },
                { 0, -1 }, { 0, 1 },
                { 1, -1 }, { 1, 0 }, { 1, 1 }

        };

        /*
         * if (row != grid.length - 1 || col != grid.length - 1 || row != 0 || col != 0)
         * {
         * 
         * if (grid[row - 1][col - 1] == true) {
         * aliveCells++; // top left
         * }
         * 
         * if (grid[row - 1][col] == true) {
         * aliveCells++; // top mid
         * }
         * 
         * if (grid[row][col - 1] == true) {
         * aliveCells++; // middle left
         * }
         * 
         * if (grid[row - 1][col + 1] == true) {
         * aliveCells++; // top right
         * }
         * 
         * if (grid[row][col + 1] == true) {
         * aliveCells++; // middle right
         * }
         * 
         * if (grid[row + 1][col - 1] == true) {
         * aliveCells++; // bottom left
         * }
         * 
         * if (grid[row + 1][col] == true) {
         * aliveCells++; // bottom middle
         * }
         * 
         * if (grid[row + 1][col + 1] == true) {
         * aliveCells++; // bottom right
         * }
         * 
         * }
         * 
         * if (row == 0 || col == 0 || row == grid.length-1 || col == grid.length-1){
         * 
         */

        for (int i = 0; i < edgeCases.length; i++) {
            int neighborRow = (row + edgeCases[i][0] + grid.length) % grid.length;
            int neighborCol = (col + edgeCases[i][1] + grid[0].length) % grid[0].length;

            if (grid[neighborRow][neighborCol] == true) {
                aliveCells++;
            }
        }

        // }

        // if ((row == 0 && col == 0) || (row == 0 && col == grid.length-1) || (row ==
        // grid.length-1 && col == 0) ||
        // (row == grid.length-1 && col == grid.length-1)){ }

        /*
         * if (row == 0 && col == 0) {
         * if (grid[row][col + 1] == true) {
         * aliveCells++; // direct right
         * }
         * 
         * if (grid[row + 1][col] == true) {
         * aliveCells++; // direct bottom
         * }
         * 
         * if (grid[row + 1][col + 1] == true) {
         * aliveCells++; // diagonal bottom right
         * }
         * 
         * if (grid[grid.length - 1][0] == true) {
         * aliveCells++;
         * }
         * 
         * if (grid[grid.length - 1][1] == true) {
         * aliveCells++;
         * }
         * 
         * if (grid[grid.length - 1][grid.length - 1] == true) {
         * aliveCells++;
         * }
         * 
         * if (grid[0][grid.length - 1] == true) {
         * aliveCells++;
         * }
         * 
         * if (grid[1][grid.length - 1] == true) {
         * aliveCells++;
         * }
         * 
         * }
         */

        // for regular cases

        return aliveCells;

    }

    /**
     * Creates a new grid with the next generation of the current grid using
     * the rules for Conway's Game of Life.
     * 
     * @return boolean[][] of new grid (this is a new 2D array)
     */
    public boolean[][] computeNewGrid() {

        boolean[][] newGrid = new boolean[grid.length][grid[0].length];

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {

                if ((numOfAliveNeighbors(i, j) == 2 || numOfAliveNeighbors(i, j) == 3) && grid[i][j] == true) {
                    newGrid[i][j] = true;
                }

                if ((numOfAliveNeighbors(i, j) == 0 || numOfAliveNeighbors(i, j) == 1) && grid[i][j] == true) {
                    newGrid[i][j] = false;
                }

                if (numOfAliveNeighbors(i, j) == 3 && grid[i][j] == false) {
                    newGrid[i][j] = true;
                }

                if (numOfAliveNeighbors(i, j) >= 4 && grid[i][j] == true) {
                    newGrid[i][j] = false;
                }

            }
        }

        return newGrid;
    }

    /**
     * Updates the current grid (the grid instance variable) with the grid denoting
     * the next generation of cells computed by computeNewGrid().
     * 
     * Updates totalAliveCells instance variable
     */
    public void nextGeneration() {

        grid = computeNewGrid();

    }

    /**
     * Updates the current grid with the grid computed after multiple (n)
     * generations.
     * 
     * @param n number of iterations that the grid will go through to compute a new
     *          grid
     */
    public void nextGeneration(int n) {

        for (int i = 0; i < n; i++) {
            nextGeneration();
        }
    }

    /**
     * Determines the number of separate cell communities in the grid
     * 
     * @return the number of communities in the grid, communities can be formed from
     *         edges
     */
    public int numOfCommunities() {

        WeightedQuickUnionUF union = new WeightedQuickUnionUF(grid.length, grid[0].length);

        int[][] edgeCases = { { -1, -1 }, { -1, 0 }, { -1, 1 },
                { 0, -1 }, { 0, 1 },
                { 1, -1 }, { 1, 0 }, { 1, 1 }

        };

        ArrayList<Integer> community = new ArrayList<Integer>();

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j] == true) {
                    for (int a = 0; a < edgeCases.length; a++) {
                        int neighborRow = (i + edgeCases[a][0] + grid.length) % grid.length;
                        int neighborCol = (j + edgeCases[a][1] + grid[0].length) % grid[0].length;

                        if (grid[neighborRow][neighborCol] == true) { // maybe && !(community.contains(union.find(i,j))
                            union.union(i, j, neighborRow, neighborCol);

                         //   if (!community.contains(union.find(i, j))) {
                               // community.add(union.find(i, j));
                        }

                    }
                }

            }

        }

        
        
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j] == true && !community.contains(union.find(i,j))){
         
                     community.add(union.find(i,j));
          
                 }
         
            }
         
        }
         



        return community.size();

    }

}
