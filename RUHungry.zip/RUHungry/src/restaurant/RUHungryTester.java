package restaurant;

import java.util.Hashtable;

public class RUHungryTester {

    public static void main(String[] args){


        Hashtable<String, Integer> ht = new Hashtable<>();
       // ht = stockVar;
        //System.out.println(ht.toString());


    }
    
    
}
