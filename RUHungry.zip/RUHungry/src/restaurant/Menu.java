package restaurant;

/**
 * Use this class to test your Menu method.
 * This class takes in two arguments:
 * - args[0] is the menu input file
 * - args[1] is the output file
 * 
 * This class:
 * - Reads the input and output file names from args
 * - Instantiates a new RUHungry object
 * - Calls the menu() method
 * - Sets standard output to the output and prints the restaurant
 * to that file
 * 
 * To run: java -cp bin restaurant.Menu menu.in menu.out
 * 
 */
public class Menu {
        public static void main(String[] args) {

                // 1. Read input files
                // Option to hardcode these values if you don't want to use the command line
                // arguments

                //String inputFile = args[0];
                //String outputFile = args[1];
                //String file = args[2];
                // String donationfile = args[3];
                // String restock = args[3];

                // 2. Instantiate an RUHungry object
                RUHungry rh = new RUHungry();

                // 3. Call the menu() method to read the menu
                rh.menu("menu.in");
                rh.createStockHashTable("stock.in");

                // TEST METHOD 4
                // StockNode toFind = rh.findStockNode(117);
                // String name = toFind.getIngredient().getName();
                // System.out.println("The name of the ingredient you're looking for is " +
                // name);

                // TEST METHOD 5
                // rh.updateStock("Lemon",-1,-10); to test when ID is null
                // rh.updateStock(null,148,-10); to test when name is null
                // rh.updateStock("Lemon",148,-10); to test when neither are null

                // TEST METHOD 6
                rh.updatePriceAndProfit();

                // TEST METHOD 7
                // TransactionData tester = new TransactionData("order", "Water", 40, 21.52,
                // true);

                // rh.addTransactionNode(tester);
                // rh.addTransactionNode(tester);
                // rh.addTransactionNode(tester);

                // CHECK HELPER METHOD 1

                String dishName = "scarlet's sandwich";
                int numOfDishes = 4;
                //boolean tester = rh.checkDishAvailability(dishName, numOfDishes);
                //System.out.println("The dish you are checking is " + dishName + " and it's availability to make "
                               // + numOfDishes + " is " + tester);

                // CHECK HELPER METHOD 2
                // String test = "ru & og cheesecake";
                // int index = rh.findIndexOfMenuNode(test);

                // System.out.println("The index of " + test + " is " + index);

                // TEST METHOD 8
                rh.readFileForOrder("order1.in");

                // TEST METHOD 10
                // rh.readFileForDonation(donationfile);

                // TEST METHOD 11
                // rh.readFileForRestock(restock);

                //TEST TRANSACTION FILE
                //rh.readFileForTransactions("transaction1.in");

                // 4. Set output file
                // Option to remove this line if you want to print directly to the screen
                // StdOut.setFile(outputFile);

                // 5. Print restaurant
                rh.printRestaurant();

        }
}
