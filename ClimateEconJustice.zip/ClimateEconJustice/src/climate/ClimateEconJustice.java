package climate;

import java.util.ArrayList;

/**
 * This class contains methods which perform various operations on a layered
 * linked list structure that contains USA communitie's Climate and Economic
 * information.
 * 
 * @author Navya Sharma
 */

public class ClimateEconJustice {

    private StateNode firstState;

    /*
     * Constructor
     * 
     * **** DO NOT EDIT *****
     */
    public ClimateEconJustice() {
        firstState = null;
    }

    /*
     * Get method to retrieve instance variable firstState
     * 
     * @return firstState
     * 
     * **** DO NOT EDIT *****
     */
    public StateNode getFirstState() {
        // DO NOT EDIT THIS CODE
        return firstState;
    }

    /**
     * Creates 3-layered linked structure consisting of state, county,
     * and community objects by reading in CSV file provided.
     * 
     * @param inputFile, the file read from the Driver to be used for
     * @return void
     * 
     *         **** DO NOT EDIT *****
     */
    public void createLinkedStructure(String inputFile) {

        // DO NOT EDIT THIS CODE
        StdIn.setFile(inputFile);
        StdIn.readLine();

        // Reads the file one line at a time
        while (StdIn.hasNextLine()) {
            // Reads a single line from input file
            String line = StdIn.readLine();
            // IMPLEMENT these methods
            addToStateLevel(line);
            addToCountyLevel(line);
            addToCommunityLevel(line);
        }
    }

    /*
     * Adds a state to the first level of the linked structure.
     * Do nothing if the state is already present in the structure.
     * 
     * @param inputLine a line from the input file
     */
    public void addToStateLevel(String inputLine) {

        String[] state = inputLine.split(",");
        String stateName = state[2];

        StateNode newNode = new StateNode(stateName, null, null);

        if (firstState == null) {
            firstState = newNode;

        } else if (firstState != null) {
            StateNode pointer = firstState;
            while (pointer != null) {
                if (pointer.next == null && !pointer.getName().equals(stateName)) {
                    pointer.next = newNode;

                } else if (pointer.getName().equals(stateName)) {
                    break;
                }

                pointer = pointer.next;
            }
        }

    }

    /*
     * Adds a county to a state's list of counties.
     * 
     * Access the state's list of counties' using the down pointer from the State
     * class.
     * Do nothing if the county is already present in the structure.
     * 
     * @param inputFile a line from the input file
     */
    public void addToCountyLevel(String inputLine) {

        String[] info = inputLine.split(",");
        String state = info[2];
        String county = info[1];

        CountyNode countyNode = new CountyNode(county, null, null);
        StateNode statePointer = firstState;
        CountyNode countyPointer = new CountyNode();

        while (statePointer != null) {

            if (statePointer.getName().equals(state) && statePointer.getDown() == null) {
                statePointer.setDown(countyNode);

            } else {

                if (statePointer.getName().equals(state) && statePointer.getDown() != null) {

                    // statePointer.setDown(countyPointer);
                    countyPointer = statePointer.getDown();

                    while (countyPointer != null) {

                        if (!countyPointer.getName().equals(county) && countyPointer.next == null) {
                            countyPointer.next = countyNode;

                        } else if (countyPointer.getName().equals(county)) {
                            break;
                        }

                        countyPointer = countyPointer.next;

                    }

                }
            }

            statePointer = statePointer.next;

        }
    }

    /*
     * Adds a community to a county's list of communities.
     * 
     * Access the county through its state
     * - search for the state first,
     * - then search for the county.
     * Use the state name and the county name from the inputLine to search.
     * 
     * Access the state's list of counties using the down pointer from the StateNode
     * class.
     * Access the county's list of communities using the down pointer from the
     * CountyNode class.
     * Do nothing if the community is already present in the structure.
     * 
     * @param inputFile a line from the input file
     */
    public void addToCommunityLevel(String inputLine) {

        String[] info = inputLine.split(",");
        String community = info[0];
        String countyName = info[1];
        String stateName = info[2];
        StateNode statePointer = firstState;
        CountyNode countyPointer = new CountyNode();
        CommunityNode commNode = new CommunityNode();
        CommunityNode commPointer = new CommunityNode();

        Data dataLine = new Data(Double.parseDouble(info[3]), Double.parseDouble(info[4]), Double.parseDouble(info[5]),
                Double.parseDouble(info[8]), Double.parseDouble(info[9]), info[19], Double.parseDouble(info[49]),
                Double.parseDouble(info[37]), Double.parseDouble(info[121]));

        CommunityNode data = new CommunityNode(community, null, dataLine);

        while (statePointer != null) {

            if (statePointer.getName().equals(stateName)) {
                countyPointer = statePointer.getDown();
                // statePointer.setDown(countyPointer);
                break;

            }

            statePointer = statePointer.next;
        }

        while (countyPointer != null) {
            if (countyPointer.getName().equals(countyName) && countyPointer.down == null) {
                countyPointer.setDown(data); // was commNode

            } else if (countyPointer.getName().equals(countyName) && countyPointer.down != null) {
                commPointer = countyPointer.getDown();

                while (commPointer != null) {

                    if (commPointer.next == null) {
                        commPointer.next = data; // was commNode
                        break;
                    }

                    commPointer = commPointer.next;

                }
            }

            countyPointer = countyPointer.next;
        }

    }

    /**
     * Given a certain percentage and racial group inputted by user, returns
     * the number of communities that have that said percentage or more of racial
     * group
     * and are identified as disadvantaged
     * 
     * Percentages should be passed in as integers for this method.
     * 
     * @param userPrcntage the percentage which will be compared with the racial
     *                     groups
     * @param race         the race which will be returned
     * @return the amount of communities that contain the same or higher percentage
     *         of the given race
     */
    public int disadvantagedCommunities(double userPrcntage, String race) {

        StateNode statePointer = firstState;
        CountyNode countyPointer = new CountyNode();
        CommunityNode commPointer = new CommunityNode();
        int counter = 0;

        while (statePointer != null) {

            // statePointer.setDown(countyPointer);
            countyPointer = statePointer.getDown();

            while (countyPointer != null) {

                // countyPointer.setDown(commPointer);
                commPointer = countyPointer.getDown();

                while (commPointer != null) {

                    if (race.equalsIgnoreCase("African American") == true) {
                        if ((commPointer.getInfo().getPrcntAfricanAmerican() * 100) >= userPrcntage
                                && commPointer.getInfo().getAdvantageStatus().equalsIgnoreCase("true")) {

                            counter++;

                        }
                    }

                    if (race.equalsIgnoreCase("Native American") == true) {
                        if (commPointer.getInfo().getPrcntNative() * 100 >= userPrcntage
                                && commPointer.getInfo().getAdvantageStatus().equalsIgnoreCase("true")) {

                            counter++;

                        }

                    }

                    if (race.equalsIgnoreCase("Asian American") == true) {
                        if (commPointer.getInfo().getPrcntAsian() * 100 >= userPrcntage
                                && commPointer.getInfo().getAdvantageStatus().equalsIgnoreCase("true")) {

                            counter++;

                        }

                    }

                    if (race.equalsIgnoreCase("White American") == true) {
                        if (commPointer.getInfo().getPrcntWhite() * 100 >= userPrcntage
                                && commPointer.getInfo().getAdvantageStatus().equalsIgnoreCase("true")) {

                            counter++;

                        }

                    }

                    if (race.equalsIgnoreCase("Hispanic American") == true) {
                        if (commPointer.getInfo().getPrcntHispanic() * 100 >= userPrcntage
                                && commPointer.getInfo().getAdvantageStatus().equalsIgnoreCase("true")) {

                            counter++;

                        }

                    }

                    commPointer = commPointer.next;

                }

                countyPointer = countyPointer.next;

            }

            statePointer = statePointer.next;

        }

        return counter;
    }

    /**
     * Given a certain percentage and racial group inputted by user, returns
     * the number of communities that have that said percentage or more of racial
     * group
     * and are identified as non disadvantaged
     * 
     * Percentages should be passed in as integers for this method.
     * 
     * @param userPrcntage the percentage which will be compared with the racial
     *                     groups
     * @param race         the race which will be returned
     * @return the amount of communities that contain the same or higher percentage
     *         of the given race
     */
    public int nonDisadvantagedCommunities(double userPrcntage, String race) {
        StateNode statePointer = firstState;
        CountyNode countyPointer = new CountyNode();
        CommunityNode commPointer = new CommunityNode();
        int counter = 0;

        while (statePointer != null) {

            // statePointer.setDown(countyPointer);
            countyPointer = statePointer.getDown();

            while (countyPointer != null) {

                // countyPointer.setDown(commPointer);
                commPointer = countyPointer.getDown();

                while (commPointer != null) {

                    if (race.equalsIgnoreCase("African American") == true) {
                        if ((commPointer.getInfo().getPrcntAfricanAmerican() * 100) >= userPrcntage
                                && commPointer.getInfo().getAdvantageStatus().equalsIgnoreCase("false")) {

                            counter++;

                        }
                    }

                    if (race.equalsIgnoreCase("Native American") == true) {
                        if (commPointer.getInfo().getPrcntNative() * 100 >= userPrcntage
                                && commPointer.getInfo().getAdvantageStatus().equalsIgnoreCase("false")) {

                            counter++;

                        }

                    }

                    if (race.equalsIgnoreCase("Asian American") == true) {
                        if (commPointer.getInfo().getPrcntAsian() * 100 >= userPrcntage
                                && commPointer.getInfo().getAdvantageStatus().equalsIgnoreCase("false")) {

                            counter++;

                        }

                    }

                    if (race.equalsIgnoreCase("White American") == true) {
                        if (commPointer.getInfo().getPrcntWhite() * 100 >= userPrcntage
                                && commPointer.getInfo().getAdvantageStatus().equalsIgnoreCase("false")) {

                            counter++;

                        }

                    }

                    if (race.equalsIgnoreCase("Hispanic American") == true) {
                        if (commPointer.getInfo().getPrcntHispanic() * 100 >= userPrcntage
                                && commPointer.getInfo().getAdvantageStatus().equalsIgnoreCase("false")) {

                            counter++;

                        }

                    }

                    commPointer = commPointer.next;

                }

                countyPointer = countyPointer.next;

            }

            statePointer = statePointer.next;

        }

        return counter;
    }

    /**
     * Returns a list of states that have a PM (particulate matter) level
     * equal to or higher than value inputted by user.
     * 
     * @param PMlevel the level of particulate matter
     * @return the States which have or exceed that level
     */
    public ArrayList<StateNode> statesPMLevels(double PMlevel) {

        ArrayList <StateNode> stateList = new ArrayList<StateNode>();

        StateNode statePointer = firstState;
        CountyNode countyPointer = new CountyNode();
        CommunityNode commPointer = new CommunityNode();

        while (statePointer != null) {

            countyPointer = statePointer.getDown();

            while (countyPointer != null) {

                commPointer = countyPointer.getDown();

                while (commPointer != null) {

                    if (commPointer.getInfo().getPMlevel() >= PMlevel){

                        if (!stateList.contains(statePointer)){
                            stateList.add(statePointer);
                        }
                        
                    }

                    commPointer = commPointer.next;

                }

                countyPointer = countyPointer.next;

            }


            statePointer = statePointer.next;

        }


        return stateList;

    }

    

    /**
     * Given a percentage inputted by user, returns the number of communities
     * that have a chance equal to or higher than said percentage of
     * experiencing a flood in the next 30 years.
     * 
     * @param userPercntage the percentage of interest/comparison
     * @return the amount of communities at risk of flooding
     */
    public int chanceOfFlood(double userPercntage) {

        
        StateNode statePointer = firstState;
        CountyNode countyPointer = new CountyNode();
        CommunityNode commPointer = new CommunityNode();
        int counter = 0;

        while (statePointer != null) {

            countyPointer = statePointer.getDown();

            while (countyPointer != null) {

                commPointer = countyPointer.getDown();

                while (commPointer != null) {

                    if (commPointer.getInfo().getChanceOfFlood() >= userPercntage) {
                            counter++;

                        }

                    commPointer = commPointer.next;

                }

                countyPointer = countyPointer.next;

            }

            statePointer = statePointer.next;

        }

        return counter;

    }   

    

    /**
     * Given a state inputted by user, returns the communities with
     * the 10 lowest incomes within said state.
     * 
     * @param stateName the State to be analyzed
     * @return the top 10 lowest income communities in the State, with no particular
     *         order
     */
    public ArrayList<CommunityNode> lowestIncomeCommunities(String stateName) {

    ArrayList <CommunityNode> commList = new ArrayList<CommunityNode>(); 
    StateNode statePointer = firstState;
    CountyNode countyPointer = new CountyNode();
    CommunityNode commPointer = new CommunityNode();
    double temp;
    boolean duplicate = false; 


    //firstState.getDown().getDown().getInfo().prcntPovertyLine;

        while (statePointer != null){

            if (statePointer.getName().equalsIgnoreCase(stateName)){

                countyPointer = statePointer.getDown();

                while (countyPointer != null){

                    commPointer = countyPointer.getDown();
                    temp = -1; // commPointer.getInfo().getPercentPovertyLine();

                    while (commPointer != null){

                       // if (commPointer.getInfo().getPercentPovertyLine() > temp){
                            if (commList.size() >= 10){

                                double min = commList.get(0).getInfo().getPercentPovertyLine();
                                int index = 0;

                                for (int i = 0; i < commList.size(); i++){

                                    if (commList.get(i).getInfo().getPercentPovertyLine() < min ){

                                        min = commList.get(i).getInfo().getPercentPovertyLine();
                                        index = i; 

                                       // if (commList.get(i).getInfo().getPercentPovertyLine() == commPointer.getInfo().getPercentPovertyLine()){

                                       // duplicate = true; 


                                        }

                                }

                                    if (commPointer.getInfo().getPercentPovertyLine() > min ){ //duplicate = false

                                        commList.set(index, commPointer);

                                    }


                                } else {

                                    commList.add(commPointer);
                                    temp = commPointer.getInfo().getPercentPovertyLine();

                                }
                                

                            

                            //    for (int i = 0; i < commList.size(); i++){

                                //    if (commList.get(i).getInfo().getPercentPovertyLine() == commPointer.getInfo().getPercentPovertyLine()){

                                   //     duplicate = true;

                                //    }

                               
                             //   }

                             //   if (duplicate == false ){


                             //   }
                              
                                
                        commPointer = commPointer.next;


                    }


                        countyPointer = countyPointer.next;

  
                }
                           


            }


            statePointer = statePointer.next;

        }


                       
        return commList; 


    }


}

