package forensic;

import java.util.ArrayList;
import java.util.Stack;

/**
 * This class represents a forensic analysis system that manages DNA data using
 * BSTs.
 * Contains methods to create, read, update, delete, and flag profiles.
 * 
 * @author Kal Pandit
 */
public class ForensicAnalysis {

    private TreeNode treeRoot; // BST's root
    private String firstUnknownSequence;
    private String secondUnknownSequence;

    public ForensicAnalysis() {
        treeRoot = null;
        firstUnknownSequence = null;
        secondUnknownSequence = null;
    }

    /**
     * Builds a simplified forensic analysis database as a BST and populates unknown
     * sequences.
     * The input file is formatted as follows:
     * 1. one line containing the number of people in the database, say p
     * 2. one line containing first unknown sequence
     * 3. one line containing second unknown sequence
     * 2. for each person (p), this method:
     * - reads the person's name
     * - calls buildSingleProfile to return a single profile.
     * - calls insertPerson on the profile built to insert into BST.
     * Use the BST insertion algorithm from class to insert.
     * 
     * DO NOT EDIT this method, IMPLEMENT buildSingleProfile and insertPerson.
     * 
     * @param filename the name of the file to read from
     */
    public void buildTree(String filename) {
        // DO NOT EDIT THIS CODE
        StdIn.setFile(filename); // DO NOT remove this line

        // Reads unknown sequences
        String sequence1 = StdIn.readLine();
        firstUnknownSequence = sequence1;
        String sequence2 = StdIn.readLine();
        secondUnknownSequence = sequence2;

        int numberOfPeople = Integer.parseInt(StdIn.readLine());

        for (int i = 0; i < numberOfPeople; i++) {
            // Reads name, count of STRs
            String fname = StdIn.readString();
            String lname = StdIn.readString();
            String fullName = lname + ", " + fname;
            // Calls buildSingleProfile to create
            Profile profileToAdd = createSingleProfile();
            // Calls insertPerson on that profile: inserts a key-value pair (name, profile)
            insertPerson(fullName, profileToAdd);
        }
    }

    /**
     * Reads ONE profile from input file and returns a new Profile.
     * Do not add a StdIn.setFile statement, that is done for you in buildTree.
     */
    public Profile createSingleProfile() {

        int numSTRs = StdIn.readInt();
        STR[] profile = new STR[numSTRs];
        String STR;
        int occurs;

        for (int i = 0; i < numSTRs; i++) {

            STR = StdIn.readString();
            occurs = StdIn.readInt();

            STR profileForArray = new STR(STR, occurs);

            profile[i] = profileForArray;
        }

        Profile profileArray = new Profile(profile);

        return profileArray;

    }

    /**
     * Inserts a node with a new (key, value) pair into
     * the binary search tree rooted at treeRoot.
     * 
     * Names are the keys, Profiles are the values.
     * USE the compareTo method on keys.
     * 
     * @param newProfile the profile to be inserted
     */
    public void insertPerson(String name, Profile newProfile) {

        TreeNode personNode = new TreeNode(name, newProfile, null, null);
        TreeNode pointer = treeRoot;

        if (pointer == null) {
            treeRoot = personNode;
        }

        while (pointer != null) {
            if (pointer.getName().compareTo(personNode.getName()) > 0) {
                if (pointer.getLeft() == null) { // if the return int is pos then the outside string is smaller, go left
                    pointer.setLeft(personNode);
                    break;

                } else {
                    pointer = pointer.getLeft();

                }

            } else if (pointer.getName().compareTo(personNode.getName()) < 0) {
                if (pointer.getRight() == null) { // if the return int is neg then the outside string is larger, go
                                                  // right
                    pointer.setRight(personNode);
                    break;

                } else {
                    pointer = pointer.getRight();
                }

            }

        }
    }

    /**
     * Traverses the BST at treeRoot to mark profiles if:
     * - For each STR in profile STRs: at least half of STR occurrences match (round
     * UP)
     * - If occurrences THROUGHOUT DNA (first + second sequence combined) matches
     * occurrences, add a match
     */
    public void flagProfilesOfInterest() {

        TreeNode pointer = treeRoot;
        ArrayList<TreeNode> list = traverse(treeRoot);

        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).getName());
        }

        for (int i = 0; i < list.size(); i++) {
            STR[] strArray = list.get(i).getProfile().getStrs();
            Double size = Math.ceil(((strArray.length)) / 2.0);
            //Double.valueOf
            int count = 0;


            for (int j = 0; j < strArray.length; j++) {

                String profileSTR = strArray[j].getStrString();

               // if (firstUnknownSequence.contains(strArray[j].getStrString()) &&
                     //   secondUnknownSequence.contains(strArray[j].getStrString())) {

                    int firstSeqOccur = numberOfOccurrences(firstUnknownSequence, profileSTR);
                    int secondSeqOccur = numberOfOccurrences(secondUnknownSequence, profileSTR);
                    int profileSeqOccur = strArray[j].getOccurrences();

                    if ((firstSeqOccur + secondSeqOccur) == profileSeqOccur) {
                        count++;

                    }

             //  }

                // if half the total number of STRs in profile occur in both seq1 and seq2, mark
                // it

                // if the profile's str is in both sequence1 and sequence 2, enter a condition;
                // if occurences of profile's str is more than sequence1 and sequence2's
                // occurences, mark;

            }

            if (count >= size) {
                list.get(i).getProfile().setInterestStatus(true);
            }

        }

    }

    /**
     * Finds the number of profiles in the BST whose interest status matches
     * isOfInterest.
     *
     * @param isOfInterest the search mode: whether we are searching for unmarked or
     *                     marked profiles. true if yes, false otherwise
     * @return the number of profiles according to the search mode marked
     */
    public int getMatchingProfileCount(boolean isOfInterest) {

        TreeNode pointer = treeRoot;
        int count = 0;
        ArrayList<TreeNode> list = traverse(treeRoot);

        for (int i = 0; i < list.size(); i++) {

            if (list.get(i).getProfile().getMarkedStatus() == isOfInterest) {
                count++;

            }
        }

        // getMatchingProfileCount(pointer.getLeft().getProfile().getMarkedStatus());
        // getMatchingProfileCount(pointer.getRight().getProfile().getMarkedStatus());

        return count;

    }

    /**
     * Helper method that counts the # of STR occurrences in a sequence.
     * Provided method - DO NOT UPDATE.
     * 
     * @param sequence the sequence to search
     * @param STR      the STR to count occurrences of
     * @return the number of times STR appears in sequence
     */
    private int numberOfOccurrences(String sequence, String STR) {

        // DO NOT EDIT THIS CODE

        int repeats = 0;
        // STRs can't be greater than a sequence
        if (STR.length() > sequence.length())
            return 0;

        // indexOf returns the first index of STR in sequence, -1 if not found
        int lastOccurrence = sequence.indexOf(STR);

        while (lastOccurrence != -1) {
            repeats++;
            // Move start index beyond the last found occurrence
            lastOccurrence = sequence.indexOf(STR, lastOccurrence + STR.length());
        }
        return repeats;
    }

    // helper method for iterating, returns arraylist
    private static ArrayList<TreeNode> traverse(TreeNode pointer) {
        ArrayList<TreeNode> inOrderTraversal = new ArrayList<>();
        Stack<TreeNode> stack = new Stack<>();
        while (true) {
            if (pointer != null) {
                stack.push(pointer);
                pointer = pointer.getLeft();

            } else {

                if (stack.isEmpty()) {
                    break;
                }

                pointer = stack.peek();
                inOrderTraversal.add(pointer);
                stack.pop();
                pointer = pointer.getRight();

            }
        }

        return inOrderTraversal;
    }

    /**
     * Uses a level-order traversal to populate an array of unmarked Strings
     * representing unmarked people's names.
     * - USE the getMatchingProfileCount method to get the resulting array length.
     * - USE the provided Queue class to investigate a node and enqueue its
     * neighbors.
     * 
     * @return the array of unmarked people
     */
    public String[] getUnmarkedPeople() {

        TreeNode pointer = treeRoot;
        int size = getMatchingProfileCount(false);
        String[] unMarkedArray = new String[size];
        int counter = 0;

        Queue<TreeNode> queue = new Queue<>();
        ArrayList<TreeNode> list = traverse(treeRoot);

        queue.enqueue(pointer);

        while (!queue.isEmpty()) {

            pointer = queue.dequeue();

            if (pointer.getProfile().getMarkedStatus() == false) {

                unMarkedArray[counter] = pointer.getName();
                counter++;

            }

            if (pointer.getLeft() != null) {

                queue.enqueue(pointer.getLeft());

            }

            if (pointer.getRight() != null) {

                queue.enqueue(pointer.getRight());

            }

        }

        return unMarkedArray;

    }

    /**
     * Removes a SINGLE node from the BST rooted at treeRoot, given a full name
     * (Last, First)
     * This is similar to the BST delete we have seen in class.
     * 
     * If a profile containing fullName doesn't exist, do nothing.
     * You may assume that all names are distinct.
     * 
     * @param fullName the full name of the person to delete
     */




    TreeNode deleteNode(TreeNode pointer, String name) {

        if (pointer == null){
            return pointer;

        }

       
        if (pointer.getName().compareTo(name) > 0) {

            pointer.setLeft(deleteNode(pointer.getLeft(), name));
            return pointer;


        } else if (pointer.getName().compareTo(name) < 0) {

            pointer.setRight(deleteNode(pointer.getRight(), name));
            return pointer;

        }
 
        //one child is null
        if (pointer.getLeft() == null) {

            TreeNode temp = pointer.getRight();
            return temp;

        } else if (pointer.getRight() == null) {

            TreeNode temp = pointer.getLeft();
            return temp;

        } else {  // neither child is null
 
            TreeNode succParent = pointer;
            TreeNode successor = pointer.getRight();

            while (successor.getLeft() != null) {
                succParent = successor;
                successor = successor.getLeft();
            }
 
            
            if (succParent != pointer){
                succParent.setLeft(successor.getRight()); 
                

            } else 

                succParent.setRight(successor.getRight()); 
                pointer.setName(successor.getName());
                pointer.setProfile(successor.getProfile());


 

                if (treeRoot.getName().equals(name)){
                    treeRoot = successor;
                }


            return pointer;

        }

    }


    public void removePerson(String fullName) {

        TreeNode pointer = treeRoot;
        TreeNode nodeToDelete = new TreeNode();
        TreeNode holder = new TreeNode();
        TreeNode successor = new TreeNode();

        if (pointer == null) {
            return;
        }

        deleteNode(treeRoot, fullName);

    }


    /**
     * Clean up the tree by using previously written methods to remove unmarked
     * profiles.
     * Requires the use of getUnmarkedPeople and removePerson.
     */
    public void cleanupTree() {

        String[] unMarkedArray = getUnmarkedPeople();

        for (int i = 0; i < unMarkedArray.length; i++) {

            removePerson(unMarkedArray[i]);

        }

    }

    /**
     * Gets the root of the binary search tree.
     *
     * @return The root of the binary search tree.
     */
    public TreeNode getTreeRoot() {
        return treeRoot;
    }

    /**
     * Sets the root of the binary search tree.
     *
     * @param newRoot The new root of the binary search tree.
     */
    public void setTreeRoot(TreeNode newRoot) {
        treeRoot = newRoot;
    }

    /**
     * Gets the first unknown sequence.
     * 
     * @return the first unknown sequence.
     */
    public String getFirstUnknownSequence() {
        return firstUnknownSequence;
    }

    /**
     * Sets the first unknown sequence.
     * 
     * @param newFirst the value to set.
     */
    public void setFirstUnknownSequence(String newFirst) {
        firstUnknownSequence = newFirst;
    }

    /**
     * Gets the second unknown sequence.
     * 
     * @return the second unknown sequence.
     */
    public String getSecondUnknownSequence() {
        return secondUnknownSequence;
    }

    /**
     * Sets the second unknown sequence.
     * 
     * @param newSecond the value to set.
     */
    public void setSecondUnknownSequence(String newSecond) {
        secondUnknownSequence = newSecond;
    }

}
